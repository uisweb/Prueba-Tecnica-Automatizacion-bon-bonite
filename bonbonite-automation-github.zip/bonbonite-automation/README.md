# Automatización QA — bon-bonite.com

Suite de automatización E2E en **Playwright + TypeScript** para el caso
práctico de automatización de https://www.bon-bonite.com/, cubriendo:

- Registro de usuario nuevo (con validaciones negativas).
- Modificación de datos de un usuario ya registrado.
- Automatización de los módulos: Zapatos, Bolsos, Cinturones, Accesorios,
  Outlet, PQRS, Mi cuenta, Bonos de regalo.
- Tres escenarios de prueba end-to-end, incluyendo **compra de producto**.
- Generación automática del archivo de entrega `PTP_<nombre>_<apellido>_<fecha>.xlsx`
  con una pestaña por ítem funcional.

> ⚠️ Antes de entregar, revisa **PENDIENTES.md** — hay 3 ajustes que requieren
> tu confirmación o acceso al sitio en vivo.

## Estructura del proyecto

```
bonbonite-automation/
├── pages/                     # Page Objects (POM)
│   ├── BasePage.ts            # Menú principal / navegación común
│   ├── RegisterPage.ts        # Registro de usuario
│   ├── LoginPage.ts           # Login
│   ├── MyAccountPage.ts       # Edición de datos del usuario
│   ├── CategoryPage.ts        # Listados de categoría (Zapatos, Bolsos, etc.)
│   ├── ProductPage.ts         # Producto, carrito y checkout
│   └── PqrsPage.ts            # Formulario PQRS
├── tests/                     # Specs organizados por ítem funcional
│   ├── 01-registro.spec.ts
│   ├── 02-modificar-datos-usuario.spec.ts
│   ├── 03-modulos-catalogo.spec.ts
│   ├── 04-modulo-pqrs.spec.ts
│   ├── 05-modulo-mi-cuenta.spec.ts
│   ├── 06-modulo-bonos-regalo.spec.ts
│   ├── 07-escenario-compra-producto.spec.ts     (Escenario 1, obligatorio: compra)
│   ├── 08-escenario-registro-login.spec.ts      (Escenario 2)
│   └── 09-escenario-busqueda-navegacion.spec.ts (Escenario 3)
├── utils/
│   ├── testData.ts             # Datos de prueba centralizados
│   └── build-xlsx-report.ts    # Genera el archivo de entrega .xlsx
├── playwright.config.ts
├── package.json
├── tsconfig.json
└── PENDIENTES.md
```

## Requisitos

- Node.js 18+
- VS Code (recomendado, con la extensión oficial **Playwright Test for
  VSCode** para correr/depurar tests desde el editor con un clic)

## Instalación

```bash
npm install
npx playwright install --with-deps   # descarga los navegadores (Chromium, Firefox, WebKit)
```

## Configurar credenciales de prueba

```bash
export BB_USER="tu_correo_de_prueba@dominio.com"
export BB_PASS="tu_password"
```

(En Windows PowerShell: `$env:BB_USER="..."`, `$env:BB_PASS="..."`)

## Ejecutar las pruebas

```bash
npm test                # todas las pruebas, headless, 3 navegadores
npm run test:headed     # con navegador visible
npm run test:ui         # modo UI interactivo de Playwright (recomendado para depurar)
npm run test:debug      # modo paso a paso
npx playwright test tests/01-registro.spec.ts   # un solo archivo
```

### Desde VS Code
1. Instala la extensión **Playwright Test for VSCode**.
2. Abre la carpeta del proyecto.
3. En el ícono de "Testing" (frasco) verás todos los specs listados; puedes
   correr/depurar cada uno con un clic, con breakpoints incluidos.

## Ver el reporte HTML

```bash
npm run report
```

## Generar el archivo de entrega .xlsx

Después de correr `npm test` (genera `test-results/results.json`):

```bash
export PRIMER_NOMBRE="Juan"
export PRIMER_APELLIDO="Perez"
export REPO_URL="https://github.com/tu-usuario/bonbonite-automation"
npm run report:xlsx
```

Esto crea `entrega/PTP_Juan_Perez_<DDMMAAAA>.xlsx` con una pestaña por cada
ítem funcional (a-h, excepto f) y una hoja "Resumen".

## Subir el código a un repositorio

```bash
git init
git add .
git commit -m "Automatización caso práctico bon-bonite.com"
git branch -M main
git remote add origin https://github.com/tu-usuario/bonbonite-automation.git
git push -u origin main
```

Luego pega esa URL en la hoja "Item_h" del archivo .xlsx (o en la variable
`REPO_URL` antes de generar el reporte).
