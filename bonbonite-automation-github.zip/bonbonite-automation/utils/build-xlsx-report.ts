/**
 * Genera el archivo único *.xlsx de entrega con la estructura pedida:
 *   PTP_<1er_nombre>_<1er_apellido>_<fecha-inicio-prueba_DDMMAAAA>.xlsx
 * con una pestaña independiente por cada ítem funcional (a-h, excepto f) y
 * una pestaña con la URL del repositorio de código.
 *
 * Las pestañas van de "Item_a" a "Item_h" (se omite la 'f', como pide la guía).
 * Antes de generar la entrega final, completa REPO_URL con la URL real de tu
 * repositorio de código.
 *
 * Uso:
 *   PRIMER_NOMBRE=Juan PRIMER_APELLIDO=Perez REPO_URL=https://github.com/tu-usuario/tu-repo \
 *   npx ts-node utils/build-xlsx-report.ts
 */
import ExcelJS from 'exceljs';
import * as fs from 'fs';
import * as path from 'path';

interface PwSpec {
  title: string;
  file: string;
  tests: Array<{
    title: string;
    results: Array<{ status: string; duration: number; error?: { message?: string } }>;
  }>;
}

interface PwSuite {
  title: string;
  file?: string;
  suites?: PwSuite[];
  specs?: PwSpec[];
}

interface PwJsonReport {
  suites: PwSuite[];
}

const PRIMER_NOMBRE = process.env.PRIMER_NOMBRE ?? 'Nombre';
const PRIMER_APELLIDO = process.env.PRIMER_APELLIDO ?? 'Apellido';
const REPO_URL = process.env.REPO_URL ?? 'PENDIENTE: pegar aquí la URL del repositorio de código';

function fechaHoyDDMMAAAA(): string {
  const hoy = new Date();
  const dd = String(hoy.getDate()).padStart(2, '0');
  const mm = String(hoy.getMonth() + 1).padStart(2, '0');
  const yyyy = hoy.getFullYear();
  return `${dd}${mm}${yyyy}`;
}

function extraerSpecs(suites: PwSuite[], acumulado: PwSpec[] = []): PwSpec[] {
  for (const suite of suites) {
    if (suite.specs) acumulado.push(...suite.specs);
    if (suite.suites) extraerSpecs(suite.suites, acumulado);
  }
  return acumulado;
}

// Mapeo definitivo de ítem funcional -> archivos de spec que lo automatizan.
// Se omite la 'f' según lo solicitado en la guía del caso práctico.
const mapeoItems: Record<string, { titulo: string; archivos: string[] }> = {
  a: { titulo: 'a) Registro de usuario nuevo', archivos: ['01-registro.spec.ts'] },
  b: { titulo: 'b) Modificación de datos de usuario registrado', archivos: ['02-modificar-datos-usuario.spec.ts'] },
  c: { titulo: 'c) Automatización módulos de catálogo (Zapatos, Bolsos, Cinturones, Accesorios, Outlet)', archivos: ['03-modulos-catalogo.spec.ts'] },
  d: { titulo: 'd) Automatización módulo PQRS', archivos: ['04-modulo-pqrs.spec.ts'] },
  e: { titulo: 'e) Automatización módulo Mi cuenta y Bonos de regalo', archivos: ['05-modulo-mi-cuenta.spec.ts', '06-modulo-bonos-regalo.spec.ts'] },
  g: { titulo: 'g) Tres escenarios de prueba automatizados (incluye compra de producto)', archivos: ['07-escenario-compra-producto.spec.ts', '08-escenario-registro-login.spec.ts', '09-escenario-busqueda-navegacion.spec.ts'] },
  h: { titulo: 'h) URL del repositorio de código', archivos: [] },
};

async function main() {
  const resultsPath = path.resolve(__dirname, '..', 'test-results', 'results.json');
  let specs: PwSpec[] = [];
  if (fs.existsSync(resultsPath)) {
    const json: PwJsonReport = JSON.parse(fs.readFileSync(resultsPath, 'utf-8'));
    specs = extraerSpecs(json.suites);
  } else {
    console.warn('No se encontró test-results/results.json. Ejecuta "npx playwright test" primero para incluir resultados reales.');
  }

  const workbook = new ExcelJS.Workbook();
  workbook.creator = `${PRIMER_NOMBRE} ${PRIMER_APELLIDO}`;
  workbook.created = new Date();

  for (const [clave, item] of Object.entries(mapeoItems)) {
    const hoja = workbook.addWorksheet(`Item_${clave}`);
    hoja.columns = [
      { header: 'Caso de prueba', key: 'caso', width: 55 },
      { header: 'Archivo automatizado', key: 'archivo', width: 35 },
      { header: 'Resultado', key: 'resultado', width: 15 },
      { header: 'Duración (ms)', key: 'duracion', width: 15 },
      { header: 'Observaciones', key: 'obs', width: 50 },
    ];
    hoja.getRow(1).font = { bold: true };
    hoja.addRow([item.titulo]).font = { bold: true, italic: true };
    hoja.addRow([]);
    hoja.addRow(['Caso de prueba', 'Archivo automatizado', 'Resultado', 'Duración (ms)', 'Observaciones']).font = { bold: true };

    if (clave === 'h') {
      hoja.addRow(['URL del repositorio de código', '', '', '', REPO_URL]);
      continue;
    }

    const specsDelItem = specs.filter((s) => item.archivos.some((a) => s.file?.endsWith(a)));
    if (specsDelItem.length === 0) {
      hoja.addRow(['Sin resultados registrados aún (ejecutar la suite y regenerar este reporte)', '', '', '', '']);
      continue;
    }

    for (const spec of specsDelItem) {
      for (const t of spec.tests) {
        const ultimo = t.results[t.results.length - 1];
        hoja.addRow([
          t.title,
          path.basename(spec.file),
          ultimo?.status ?? 'no ejecutado',
          ultimo?.duration ?? '',
          ultimo?.error?.message?.slice(0, 200) ?? '',
        ]);
      }
    }
  }

  // Hoja resumen inicial
  const resumen = workbook.addWorksheet('Resumen', { views: [{ state: 'frozen', ySplit: 1 }] });
  resumen.columns = [
    { header: 'Campo', key: 'campo', width: 30 },
    { header: 'Valor', key: 'valor', width: 60 },
  ];
  resumen.getRow(1).font = { bold: true };
  resumen.addRow(['Proyecto', 'Caso práctico de automatización - bon-bonite.com']);
  resumen.addRow(['Herramienta', 'Playwright + TypeScript']);
  resumen.addRow(['Responsable', `${PRIMER_NOMBRE} ${PRIMER_APELLIDO}`]);
  resumen.addRow(['Fecha de inicio de prueba', fechaHoyDDMMAAAA()]);
  resumen.addRow(['URL del repositorio', REPO_URL]);
  workbook.worksheets.unshift(workbook.worksheets.pop()!); // mover "Resumen" al inicio

  const outDir = path.resolve(__dirname, '..', 'entrega');
  fs.mkdirSync(outDir, { recursive: true });
  const nombreArchivo = `PTP_${PRIMER_NOMBRE}_${PRIMER_APELLIDO}_${fechaHoyDDMMAAAA()}.xlsx`;
  const outPath = path.join(outDir, nombreArchivo);
  await workbook.xlsx.writeFile(outPath);
  console.log(`Archivo de entrega generado en: ${outPath}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
