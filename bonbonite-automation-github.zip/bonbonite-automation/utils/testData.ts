/**
 * Datos de prueba centralizados. Mantenerlos aquí facilita reutilizarlos entre
 * specs y actualizarlos en un único lugar.
 *
 * IMPORTANTE: reemplazar CREDENCIALES_USUARIO_EXISTENTE con un usuario real
 * ya registrado en el sitio antes de correr los specs que requieren login
 * (modificación de datos, compra, etc.), o dejar que el spec de registro (a)
 * cree el usuario primero dentro de la misma corrida serial.
 */

function timestamp() {
  return Date.now();
}

export const usuarioNuevo = {
  email: `qa.bonbonite.${timestamp()}@mailinator.com`,
  password: `QaTest#${timestamp()}`,
};

export const usuarioExistente = {
  usuario: process.env.BB_USER ?? 'usuario_prueba@mailinator.com',
  password: process.env.BB_PASS ?? 'CAMBIAR_PASSWORD',
};

export const datosActualizacionPerfil = {
  nombre: 'Maria',
  apellido: 'Automatizadora',
};

export const datosFacturacionCompra = {
  nombre: 'Maria',
  apellido: 'Automatizadora',
  direccion: 'Calle 45 # 30-20',
  ciudad: 'Bucaramanga',
  telefono: '3001234567',
  email: usuarioExistente.usuario,
};

export const datosPqrs = {
  nombre: 'Maria Automatizadora',
  email: 'qa.bonbonite@mailinator.com',
  asunto: 'Consulta sobre pedido - prueba automatizada',
  mensaje: 'Este es un mensaje de prueba generado por la suite de automatización QA.',
};

export const modulos = [
  { slug: 'zapatos-mujer', nombre: 'Zapatos' },
  { slug: 'bolsos', nombre: 'Bolsos' },
  { slug: 'cinturones', nombre: 'Cinturones' },
  { slug: 'accesorios', nombre: 'Accesorios' },
  { slug: 'outlet', nombre: 'Outlet' },
];
