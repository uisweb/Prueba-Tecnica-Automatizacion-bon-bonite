# Pendientes antes de entregar

## 1. ~~Literales a) - h)~~ ✅ Resuelto
Las pestañas del archivo `.xlsx` quedaron nombradas así (se omite la 'f'):
- a) Registro de usuario nuevo
- b) Modificación de datos de usuario registrado
- c) Automatización módulos de catálogo (Zapatos, Bolsos, Cinturones, Accesorios, Outlet)
- d) Automatización módulo PQRS
- e) Automatización módulo Mi cuenta y Bonos de regalo
- g) Tres escenarios de prueba automatizados (incluye compra de producto)
- h) URL del repositorio de código

## 2. ~~URL base del sitio~~ ✅ Resuelto
`https://www.bon-bonite.com` ya está configurada como `baseURL` en
`playwright.config.ts` y la usan todos los Page Objects.

## 3. Verificar selectores contra el DOM real
No pude inspeccionar el sitio en vivo (bon-bonite.com bloquea el acceso
automatizado de mi herramienta de navegación vía `robots.txt`). Los Page
Objects (`pages/*.ts`) usan selectores típicos de WooCommerce + WordPress (muy
probable a juzgar por las rutas `/mi-cuenta/`, `/categoria-producto/...`),
pero debes:
1. Abrir el sitio en tu navegador con DevTools.
2. Correr `npx playwright codegen https://www.bon-bonite.com` (abre un
   navegador y genera selectores reales mientras haces clics).
3. Ajustar los `locator(...)` marcados con comentarios "ajustar selector" si
   no calzan exactamente.

## 4. Datos de usuario reales
En `utils/testData.ts`, la constante `usuarioExistente` necesita un usuario
real ya registrado en el sitio (o corre primero el spec de registro y usa esas
credenciales). Configúralo con variables de entorno para no dejar contraseñas
en el código:

```bash
export BB_USER="tu_correo_de_prueba@dominio.com"
export BB_PASS="tu_password"
```

## 5. URL del repositorio de código
Sube el proyecto a GitHub/GitLab (ver README) y pega esa URL en la variable
`REPO_URL` al generar el `.xlsx` (o directamente en la hoja "Item_h").
