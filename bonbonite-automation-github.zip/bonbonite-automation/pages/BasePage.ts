import { Page, Locator, expect } from '@playwright/test';

/**
 * Clase base para todos los Page Objects del sitio bon-bonite.com.
 * Centraliza el manejo del header/menú principal (WooCommerce - tema Storefront/Astra,
 * ajustar selectores tras inspeccionar el DOM real si el tema difiere).
 */
export class BasePage {
  readonly page: Page;

  // Menú principal / header
  readonly menuZapatos: Locator;
  readonly menuBolsos: Locator;
  readonly menuCinturones: Locator;
  readonly menuAccesorios: Locator;
  readonly menuOutlet: Locator;
  readonly menuPqrs: Locator;
  readonly menuMiCuenta: Locator;
  readonly menuBonosRegalo: Locator;
  readonly iconoCarrito: Locator;
  readonly avisoCookies: Locator;
  readonly aceptarCookies: Locator;

  constructor(page: Page) {
    this.page = page;

    this.menuZapatos = page.getByRole('link', { name: /zapatos/i }).first();
    this.menuBolsos = page.getByRole('link', { name: /bolsos/i }).first();
    this.menuCinturones = page.getByRole('link', { name: /cinturones/i }).first();
    this.menuAccesorios = page.getByRole('link', { name: /accesorios/i }).first();
    this.menuOutlet = page.getByRole('link', { name: /outlet/i }).first();
    this.menuPqrs = page.getByRole('link', { name: /pqrs/i }).first();
    this.menuMiCuenta = page.getByRole('link', { name: /mi cuenta/i }).first();
    this.menuBonosRegalo = page.getByRole('link', { name: /bono/i }).first();
    this.iconoCarrito = page.locator('a.cart-contents, a[href*="carrito"], a[href*="cart"]').first();

    this.avisoCookies = page.locator('#cookie-law-info-bar, .cookie-notice, [class*="cookie"]').first();
    this.aceptarCookies = page.getByRole('button', { name: /aceptar|accept/i }).first();
  }

  async goto(path: string = '/') {
    await this.page.goto(path);
    await this.dismissCookiesIfPresent();
  }

  /** Cierra el banner de cookies si aparece, para no bloquear clics posteriores. */
  async dismissCookiesIfPresent() {
    try {
      if (await this.avisoCookies.isVisible({ timeout: 3000 })) {
        await this.aceptarCookies.click({ timeout: 3000 });
      }
    } catch {
      // no había banner de cookies, se continúa sin problema
    }
  }

  async irAModulo(modulo: 'zapatos' | 'bolsos' | 'cinturones' | 'accesorios' | 'outlet' | 'pqrs' | 'mi-cuenta' | 'bonos-regalo') {
    const mapa: Record<string, Locator> = {
      'zapatos': this.menuZapatos,
      'bolsos': this.menuBolsos,
      'cinturones': this.menuCinturones,
      'accesorios': this.menuAccesorios,
      'outlet': this.menuOutlet,
      'pqrs': this.menuPqrs,
      'mi-cuenta': this.menuMiCuenta,
      'bonos-regalo': this.menuBonosRegalo,
    };
    await mapa[modulo].click();
    await this.page.waitForLoadState('domcontentloaded');
  }

  async verificarModuloCargado() {
    await expect(this.page.locator('body')).toBeVisible();
    // Verificación genérica de que la página respondió correctamente (no error 404/500)
    const titulo = await this.page.title();
    expect(titulo.toLowerCase()).not.toContain('404');
  }
}
