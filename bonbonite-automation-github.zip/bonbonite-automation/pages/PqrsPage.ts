import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';

/**
 * Página del formulario PQRS (Peticiones, Quejas, Reclamos y Sugerencias).
 * Ajustar el slug/ruta y los name de los campos tras inspeccionar el formulario real
 * (frecuentemente construido con Contact Form 7 o WPForms en WordPress).
 */
export class PqrsPage extends BasePage {
  readonly campoNombre: Locator;
  readonly campoEmail: Locator;
  readonly campoAsunto: Locator;
  readonly campoMensaje: Locator;
  readonly botonEnviar: Locator;
  readonly mensajeEnvioExitoso: Locator;

  constructor(page: Page) {
    super(page);
    this.campoNombre = page.locator('input[name*="nombre" i], input#nombre').first();
    this.campoEmail = page.locator('input[type="email"]').first();
    this.campoAsunto = page.locator('input[name*="asunto" i], input#asunto').first();
    this.campoMensaje = page.locator('textarea').first();
    this.botonEnviar = page.getByRole('button', { name: /enviar/i });
    this.mensajeEnvioExitoso = page.getByText(/mensaje enviado|gracias por contactarnos|hemos recibido tu mensaje/i);
  }

  async ir() {
    await this.goto('/pqrs/');
  }

  async enviarSolicitud(datos: { nombre: string; email: string; asunto: string; mensaje: string }) {
    await this.campoNombre.fill(datos.nombre);
    await this.campoEmail.fill(datos.email);
    if (await this.campoAsunto.isVisible().catch(() => false)) {
      await this.campoAsunto.fill(datos.asunto);
    }
    await this.campoMensaje.fill(datos.mensaje);
    await this.botonEnviar.click();
  }

  async verificarEnvioExitoso() {
    await expect(this.mensajeEnvioExitoso).toBeVisible({ timeout: 15000 });
  }
}
