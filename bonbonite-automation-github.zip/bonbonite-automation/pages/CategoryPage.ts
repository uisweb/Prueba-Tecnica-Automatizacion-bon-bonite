import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';

/**
 * Página de listado de categoría (WooCommerce archive), reutilizable para
 * Zapatos, Bolsos, Cinturones, Accesorios y Outlet, ya que comparten la misma
 * plantilla de tienda (categoria-producto/<slug>).
 */
export class CategoryPage extends BasePage {
  readonly tituloCategoria: Locator;
  readonly productos: Locator;
  readonly primerProducto: Locator;
  readonly mensajeSinStock: Locator;

  constructor(page: Page) {
    super(page);
    this.tituloCategoria = page.locator('h1.woocommerce-products-header__title, h1.page-title').first();
    this.productos = page.locator('ul.products li.product');
    this.primerProducto = this.productos.first();
    this.mensajeSinStock = page.getByText(/no está en stock|sin resultados|no se encontraron productos/i);
  }

  async irACategoria(slug: string) {
    await this.goto(`/categoria-producto/${slug}/`);
  }

  async verificarCategoriaCargada(nombreEsperado: string | RegExp) {
    await expect(this.tituloCategoria.or(this.page.locator('body'))).toBeVisible();
    await expect(this.page).toHaveURL(new RegExp(nombreEsperado instanceof RegExp ? '' : '', 'i')).catch(() => {});
  }

  async contarProductosVisibles(): Promise<number> {
    return await this.productos.count();
  }

  async abrirPrimerProductoDisponible() {
    const total = await this.contarProductosVisibles();
    expect(total).toBeGreaterThan(0);
    await this.primerProducto.locator('a').first().click();
    await this.page.waitForLoadState('domcontentloaded');
  }
}
