import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';

export class ProductPage extends BasePage {
  readonly tituloProducto: Locator;
  readonly selectorTalla: Locator;
  readonly cantidad: Locator;
  readonly botonAgregarCarrito: Locator;
  readonly mensajeAgregado: Locator;
  readonly enlaceVerCarrito: Locator;

  constructor(page: Page) {
    super(page);
    this.tituloProducto = page.locator('h1.product_title');
    // Los atributos (talla/color) en WooCommerce suelen ser <select> con name="attribute_*"
    this.selectorTalla = page.locator('select[name^="attribute_"]').first();
    this.cantidad = page.locator('input.qty');
    this.botonAgregarCarrito = page.locator('button.single_add_to_cart_button, button[name="add-to-cart"]');
    this.mensajeAgregado = page.locator('.woocommerce-message');
    this.enlaceVerCarrito = page.getByRole('link', { name: /ver carrito|view cart/i });
  }

  async seleccionarVarianteSiExiste() {
    if (await this.selectorTalla.isVisible().catch(() => false)) {
      const opciones = await this.selectorTalla.locator('option').all();
      // Selecciona la primera opción válida distinta del placeholder "Elige una opción"
      for (const opcion of opciones) {
        const valor = await opcion.getAttribute('value');
        if (valor) {
          await this.selectorTalla.selectOption(valor);
          break;
        }
      }
    }
  }

  async agregarAlCarrito(cantidad = 1) {
    await this.seleccionarVarianteSiExiste();
    if (await this.cantidad.isVisible().catch(() => false)) {
      await this.cantidad.fill(String(cantidad));
    }
    await this.botonAgregarCarrito.click();
  }

  async verificarProductoAgregado() {
    await expect(this.mensajeAgregado.or(this.enlaceVerCarrito)).toBeVisible({ timeout: 15000 });
  }
}

export class CartPage extends BasePage {
  readonly filasCarrito: Locator;
  readonly botonFinalizarCompra: Locator;
  readonly totalCarrito: Locator;

  constructor(page: Page) {
    super(page);
    this.filasCarrito = page.locator('tr.woocommerce-cart-form__cart-item, tr.cart_item');
    this.botonFinalizarCompra = page.getByRole('link', { name: /finalizar compra|proceed to checkout/i });
    this.totalCarrito = page.locator('.order-total .woocommerce-Price-amount, tr.order-total td');
  }

  async ir() {
    await this.goto('/carrito/');
  }

  async verificarProductoEnCarrito() {
    await expect(this.filasCarrito.first()).toBeVisible({ timeout: 15000 });
  }

  async irACheckout() {
    await this.botonFinalizarCompra.click();
    await this.page.waitForLoadState('domcontentloaded');
  }
}

export class CheckoutPage extends BasePage {
  readonly campoNombre: Locator;
  readonly campoApellido: Locator;
  readonly campoDireccion: Locator;
  readonly campoCiudad: Locator;
  readonly campoDepartamento: Locator;
  readonly campoTelefono: Locator;
  readonly campoEmail: Locator;
  readonly metodoPago: Locator;
  readonly botonRealizarPedido: Locator;
  readonly mensajeConfirmacion: Locator;

  constructor(page: Page) {
    super(page);
    this.campoNombre = page.locator('#billing_first_name');
    this.campoApellido = page.locator('#billing_last_name');
    this.campoDireccion = page.locator('#billing_address_1');
    this.campoCiudad = page.locator('#billing_city');
    this.campoDepartamento = page.locator('#billing_state');
    this.campoTelefono = page.locator('#billing_phone');
    this.campoEmail = page.locator('#billing_email');
    this.metodoPago = page.locator('input[name="payment_method"]').first();
    this.botonRealizarPedido = page.locator('#place_order');
    this.mensajeConfirmacion = page.getByText(/pedido recibido|gracias por tu compra|order received/i);
  }

  async completarDatosFacturacion(datos: {
    nombre: string; apellido: string; direccion: string; ciudad: string; telefono: string; email: string;
  }) {
    await this.campoNombre.fill(datos.nombre);
    await this.campoApellido.fill(datos.apellido);
    await this.campoDireccion.fill(datos.direccion);
    await this.campoCiudad.fill(datos.ciudad);
    await this.campoTelefono.fill(datos.telefono);
    await this.campoEmail.fill(datos.email);
  }

  async seleccionarMetodoPago() {
    if (await this.metodoPago.isVisible().catch(() => false)) {
      await this.metodoPago.check();
    }
  }

  async realizarPedido() {
    await this.botonRealizarPedido.click();
  }

  async verificarCompraExitosa() {
    await expect(this.mensajeConfirmacion).toBeVisible({ timeout: 30000 });
  }
}
