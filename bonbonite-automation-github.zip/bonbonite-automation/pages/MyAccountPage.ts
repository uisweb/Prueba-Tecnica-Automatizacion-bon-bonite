import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';

/**
 * Sección "Detalles de la cuenta" dentro de Mi cuenta, donde WooCommerce permite
 * modificar nombre, apellido, correo y contraseña del usuario ya registrado.
 */
export class MyAccountPage extends BasePage {
  readonly enlaceDetallesCuenta: Locator;
  readonly campoNombre: Locator;
  readonly campoApellido: Locator;
  readonly campoEmail: Locator;
  readonly campoPasswordActual: Locator;
  readonly campoPasswordNueva: Locator;
  readonly campoConfirmarPassword: Locator;
  readonly botonGuardarCambios: Locator;
  readonly mensajeExito: Locator;

  constructor(page: Page) {
    super(page);
    this.enlaceDetallesCuenta = page.getByRole('link', { name: /detalles de la cuenta|account details/i });
    this.campoNombre = page.locator('input#account_first_name');
    this.campoApellido = page.locator('input#account_last_name');
    this.campoEmail = page.locator('input#account_email');
    this.campoPasswordActual = page.locator('input#password_current');
    this.campoPasswordNueva = page.locator('input#password_1');
    this.campoConfirmarPassword = page.locator('input#password_2');
    this.botonGuardarCambios = page.getByRole('button', { name: /guardar cambios|save changes/i });
    this.mensajeExito = page.locator('.woocommerce-message');
  }

  async irADetallesCuenta() {
    await this.goto('/mi-cuenta/edit-account/');
  }

  async actualizarDatosPersonales(nombre: string, apellido: string) {
    await this.campoNombre.fill(nombre);
    await this.campoApellido.fill(apellido);
    await this.botonGuardarCambios.click();
  }

  async cambiarCorreo(nuevoCorreo: string, passwordActual: string) {
    await this.campoEmail.fill(nuevoCorreo);
    await this.campoPasswordActual.fill(passwordActual);
    await this.botonGuardarCambios.click();
  }

  async verificarActualizacionExitosa() {
    await expect(this.mensajeExito).toBeVisible({ timeout: 15000 });
    await expect(this.mensajeExito).toContainText(/guardad|actualizad/i);
  }
}
