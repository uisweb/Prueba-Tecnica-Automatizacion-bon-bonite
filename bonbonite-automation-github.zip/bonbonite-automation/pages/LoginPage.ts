import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';

/**
 * Formulario de LOGIN en /mi-cuenta/.
 * Selectores confirmados con Playwright Codegen sobre el sitio real:
 * el login usa "Número de cédula" (no correo) como usuario.
 */
export class LoginPage extends BasePage {
  readonly campoUsuario: Locator;
  readonly campoPassword: Locator;
  readonly botonIngresar: Locator;
  readonly mensajeError: Locator;

  constructor(page: Page) {
    super(page);
    this.campoUsuario = page.getByRole('textbox', { name: /número de cédula/i });
    this.campoPassword = page.getByRole('textbox', { name: /^contraseña/i });
    this.botonIngresar = page.getByRole('button', { name: /iniciar sesión/i });
    this.mensajeError = page.locator('.woocommerce-error, [role="alert"]');
  }

  async ir() {
    await this.goto('/mi-cuenta/');
  }

  async iniciarSesion(usuario: string, password: string) {
    await this.campoUsuario.fill(usuario);
    await this.campoPassword.fill(password);
    await this.botonIngresar.click();
  }

  async verificarSesionIniciada() {
    await expect(this.page.getByText(/hola,/i)).toBeVisible({ timeout: 15000 });
  }
}