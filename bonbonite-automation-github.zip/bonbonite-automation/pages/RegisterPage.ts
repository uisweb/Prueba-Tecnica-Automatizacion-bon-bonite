import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';

/**
 * Página "Mi cuenta" - bloque de REGISTRO.
 * Selectores confirmados con Playwright Codegen sobre el sitio real:
 * el formulario de registro está oculto dentro de #customer_register y se
 * revela al hacer clic en el enlace/botón con id #show_register.
 */
export class RegisterPage extends BasePage {
  readonly enlaceMostrarRegistro: Locator;
  readonly contenedorRegistro: Locator;
  readonly campoEmailRegistro: Locator;
  readonly campoPasswordRegistro: Locator;
  readonly botonRegistrar: Locator;
  readonly mensajeError: Locator;
  readonly mensajeExito: Locator;

  constructor(page: Page) {
    super(page);
    this.enlaceMostrarRegistro = page.locator('#show_register');
    this.contenedorRegistro = page.locator('#customer_register');
    this.campoEmailRegistro = this.contenedorRegistro.getByRole('textbox', { name: /correo electró/i });
    this.campoPasswordRegistro = this.contenedorRegistro.getByRole('textbox', { name: /contraseña/i });
    this.botonRegistrar = this.contenedorRegistro.getByRole('button');
    this.mensajeError = page.locator('.woocommerce-error, .woocommerce-notices-wrapper .error, [role="alert"]');
    this.mensajeExito = page.locator('.woocommerce-message, .woocommerce-notices-wrapper .success');
  }

  async ir() {
    await this.goto('/mi-cuenta/');
    await this.revelarFormularioRegistroSiEstaOculto();
  }

  async revelarFormularioRegistroSiEstaOculto() {
    if (await this.campoEmailRegistro.isVisible().catch(() => false)) return;
    if (await this.enlaceMostrarRegistro.isVisible().catch(() => false)) {
      await this.enlaceMostrarRegistro.click();
    }
    await this.campoEmailRegistro.waitFor({ state: 'visible', timeout: 10000 }).catch(() => {});
  }

  async registrarNuevoUsuario(email: string, password: string) {
    await this.revelarFormularioRegistroSiEstaOculto();
    await this.campoEmailRegistro.fill(email);
    if (await this.campoPasswordRegistro.isVisible().catch(() => false)) {
      await this.campoPasswordRegistro.fill(password);
    }
    await this.botonRegistrar.click();
  }

  async verificarRegistroExitoso() {
    await expect(this.page.getByText(/hola,/i).or(this.mensajeExito)).toBeVisible({ timeout: 15000 });
  }

  async verificarErrorRegistro(mensajeEsperadoParcial?: string) {
    await expect(this.mensajeError).toBeVisible();
    if (mensajeEsperadoParcial) {
      await expect(this.mensajeError).toContainText(mensajeEsperadoParcial, { ignoreCase: true });
    }
  }
}