import { test } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { CategoryPage } from '../pages/CategoryPage';
import { ProductPage, CartPage, CheckoutPage } from '../pages/ProductPage';
import { usuarioExistente, datosFacturacionCompra } from '../utils/testData';

/**
 * ESCENARIO DE PRUEBA 1 (obligatorio): Compra de producto end-to-end.
 * Flujo: login -> navegar a categoría Zapatos -> abrir un producto -> seleccionar
 * variante -> agregar al carrito -> ir a checkout -> completar datos de facturación
 * -> confirmar pedido.
 */
test('Escenario 1 - Compra completa de un producto de principio a fin', async ({ page }) => {
  const login = new LoginPage(page);
  await login.ir();
  await login.iniciarSesion(usuarioExistente.usuario, usuarioExistente.password);
  await login.verificarSesionIniciada();

  const categoria = new CategoryPage(page);
  await categoria.irACategoria('zapatos-mujer');
  await categoria.abrirPrimerProductoDisponible();

  const producto = new ProductPage(page);
  await producto.agregarAlCarrito(1);
  await producto.verificarProductoAgregado();

  const carrito = new CartPage(page);
  await carrito.ir();
  await carrito.verificarProductoEnCarrito();
  await carrito.irACheckout();

  const checkout = new CheckoutPage(page);
  await checkout.completarDatosFacturacion(datosFacturacionCompra);
  await checkout.seleccionarMetodoPago();
  await checkout.realizarPedido();
  await checkout.verificarCompraExitosa();
});
