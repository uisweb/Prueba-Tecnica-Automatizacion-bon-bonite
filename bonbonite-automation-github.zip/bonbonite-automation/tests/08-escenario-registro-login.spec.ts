import { test } from '@playwright/test';
import { RegisterPage } from '../pages/RegisterPage';
import { LoginPage } from '../pages/LoginPage';
import { usuarioNuevo } from '../utils/testData';

/**
 * ESCENARIO DE PRUEBA 2: Registro de un cliente potencial y verificación de que
 * puede loguearse inmediatamente después con las credenciales creadas.
 */
test('Escenario 2 - Registro de usuario nuevo y login inmediato', async ({ page }) => {
  const registro = new RegisterPage(page);
  await registro.ir();
  await registro.registrarNuevoUsuario(usuarioNuevo.email, usuarioNuevo.password);
  await registro.verificarRegistroExitoso();

  // WooCommerce suele dejar la sesión iniciada tras el registro; se cierra sesión
  // y se vuelve a loguear para validar explícitamente el flujo de login.
  await page.goto('/mi-cuenta/');
  const cerrarSesion = page.getByRole('link', { name: /cerrar sesión|logout/i });
  if (await cerrarSesion.isVisible().catch(() => false)) {
    await cerrarSesion.click();
  }

  const login = new LoginPage(page);
  await login.ir();
  await login.iniciarSesion(usuarioNuevo.email, usuarioNuevo.password);
  await login.verificarSesionIniciada();
});
