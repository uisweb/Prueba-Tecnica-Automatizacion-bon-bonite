import { test, expect } from '@playwright/test';
import { BasePage } from '../pages/BasePage';

/**
 * Ítem funcional: módulo "Bonos de regalo".
 * Verifica que la página de bonos cargue y muestre las opciones de compra de bono.
 */
test.describe('Módulo Bonos de regalo', () => {
  test('La página de bonos de regalo carga correctamente', async ({ page }) => {
    const base = new BasePage(page);
    await base.goto('/');
    await base.menuBonosRegalo.click();
    await base.verificarModuloCargado();
    await expect(page).toHaveURL(/bono/i);
  });
});
