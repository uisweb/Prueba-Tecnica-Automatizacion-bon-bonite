import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { MyAccountPage } from '../pages/MyAccountPage';
import { usuarioExistente, datosActualizacionPerfil } from '../utils/testData';

/**
 * Ítem funcional: Modificación de datos de un usuario ya registrado.
 * Requiere un usuario válido ya existente (ver utils/testData.ts -> usuarioExistente,
 * configurable mediante las variables de entorno BB_USER y BB_PASS).
 */
test.describe('Modificación de datos de usuario', () => {
  test.beforeEach(async ({ page }) => {
    const login = new LoginPage(page);
    await login.ir();
    await login.iniciarSesion(usuarioExistente.usuario, usuarioExistente.password);
    await login.verificarSesionIniciada();
  });

  test('El usuario puede modificar su nombre y apellido correctamente', async ({ page }) => {
    const cuenta = new MyAccountPage(page);
    await cuenta.irADetallesCuenta();
    await cuenta.actualizarDatosPersonales(
      datosActualizacionPerfil.nombre,
      datosActualizacionPerfil.apellido
    );
    await cuenta.verificarActualizacionExitosa();
  });

  test('El sistema exige la contraseña actual para confirmar un cambio de correo', async ({ page }) => {
    const cuenta = new MyAccountPage(page);
    await cuenta.irADetallesCuenta();
    await cuenta.campoEmail.fill('nuevo.correo.qa@mailinator.com');
    // Se deja la contraseña actual vacía a propósito para validar el mensaje de error
    await cuenta.botonGuardarCambios.click();
    await expect(page.locator('.woocommerce-error')).toBeVisible();
  });
});
