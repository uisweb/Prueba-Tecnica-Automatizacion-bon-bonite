import { test } from '@playwright/test';
import { RegisterPage } from '../pages/RegisterPage';
import { usuarioNuevo } from '../utils/testData';

/**
 * Ítem funcional: Registro de usuario nuevo.
 * Verifica que un cliente potencial pueda registrarse exitosamente en el sitio
 * para luego poder loguearse y comprar.
 */
test.describe('Registro de usuario', () => {
  test('Un usuario nuevo puede registrarse correctamente con datos válidos', async ({ page }) => {
    const registro = new RegisterPage(page);
    await registro.ir();
    await registro.registrarNuevoUsuario(usuarioNuevo.email, usuarioNuevo.password);
    await registro.verificarRegistroExitoso();
  });

  test('El sistema rechaza el registro con un correo ya utilizado', async ({ page }) => {
    const registro = new RegisterPage(page);
    await registro.ir();
    // Se reutiliza el mismo correo del test anterior para forzar el error de duplicado
    await registro.registrarNuevoUsuario(usuarioNuevo.email, usuarioNuevo.password);
    await registro.verificarErrorRegistro('ya está registrada');
  });

  test('El sistema rechaza el registro con un correo con formato inválido', async ({ page }) => {
    const registro = new RegisterPage(page);
    await registro.ir();
    await registro.registrarNuevoUsuario('correo-invalido-sin-arroba', 'ClaveSegura#123');
    await registro.verificarErrorRegistro();
  });
});
