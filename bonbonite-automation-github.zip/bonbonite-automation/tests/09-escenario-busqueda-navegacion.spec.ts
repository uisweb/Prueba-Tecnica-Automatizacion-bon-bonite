import { test, expect } from '@playwright/test';
import { BasePage } from '../pages/BasePage';

/**
 * ESCENARIO DE PRUEBA 3: Búsqueda de producto desde el buscador general del sitio
 * y navegación cruzada entre los módulos del menú principal, validando que ningún
 * módulo quede roto.
 */
test('Escenario 3 - Búsqueda de producto y navegación entre módulos del menú', async ({ page }) => {
  const base = new BasePage(page);
  await base.goto('/');

  const buscador = page.locator('input[type="search"], input[name="s"]').first();
  await buscador.fill('zapato');
  await buscador.press('Enter');
  await page.waitForLoadState('domcontentloaded');
  await expect(page).toHaveURL(/s=zapato|search/i);

  // Navegación cruzada por los módulos principales
  for (const modulo of ['zapatos', 'bolsos', 'cinturones', 'accesorios', 'outlet'] as const) {
    await base.goto('/');
    await base.irAModulo(modulo);
    await base.verificarModuloCargado();
  }
});
