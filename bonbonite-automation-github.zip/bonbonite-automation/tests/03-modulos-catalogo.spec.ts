import { test, expect } from '@playwright/test';
import { CategoryPage } from '../pages/CategoryPage';
import { modulos } from '../utils/testData';

/**
 * Ítem funcional: automatización de los módulos de catálogo.
 * Se valida, para cada módulo (Zapatos, Bolsos, Cinturones, Accesorios, Outlet),
 * que la categoría cargue correctamente y muestre al menos un producto o el
 * mensaje de "sin stock" (nunca un error del sitio).
 */
test.describe('Módulos de catálogo', () => {
  for (const modulo of modulos) {
    test(`El módulo ${modulo.nombre} carga correctamente y responde sin errores`, async ({ page }) => {
      const categoria = new CategoryPage(page);
      await categoria.irACategoria(modulo.slug);
      await categoria.verificarModuloCargado();
      await expect(page.locator('body')).not.toContainText(/error 404|página no encontrada/i);
    });
  }
});
