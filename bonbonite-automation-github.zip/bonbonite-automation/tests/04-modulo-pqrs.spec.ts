import { test } from '@playwright/test';
import { PqrsPage } from '../pages/PqrsPage';
import { datosPqrs } from '../utils/testData';

/**
 * Ítem funcional: módulo PQRS.
 * Verifica que un cliente pueda radicar una petición/queja/reclamo/sugerencia
 * y reciba confirmación de envío.
 */
test.describe('Módulo PQRS', () => {
  test('El formulario PQRS se envía correctamente con datos válidos', async ({ page }) => {
    const pqrs = new PqrsPage(page);
    await pqrs.ir();
    await pqrs.enviarSolicitud(datosPqrs);
    await pqrs.verificarEnvioExitoso();
  });

  test('El formulario PQRS valida los campos obligatorios vacíos', async ({ page }) => {
    const pqrs = new PqrsPage(page);
    await pqrs.ir();
    await pqrs.botonEnviar.click();
    // Se espera que el formulario no navegue / muestre validación nativa u error propio
    await pqrs.verificarModuloCargado();
  });
});
