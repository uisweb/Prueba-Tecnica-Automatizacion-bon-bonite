import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { usuarioExistente } from '../utils/testData';

/**
 * Ítem funcional: módulo "Mi cuenta".
 * Valida el acceso al panel general y la disponibilidad de sus secciones
 * (pedidos, direcciones, detalles de la cuenta).
 */
test.describe('Módulo Mi cuenta', () => {
  test('El usuario autenticado visualiza el panel de Mi cuenta con sus secciones', async ({ page }) => {
    const login = new LoginPage(page);
    await login.ir();
    await login.iniciarSesion(usuarioExistente.usuario, usuarioExistente.password);
    await login.verificarSesionIniciada();

    await expect(page.getByRole('link', { name: /pedidos|orders/i })).toBeVisible();
    await expect(page.getByRole('link', { name: /direcciones|addresses/i })).toBeVisible();
    await expect(page.getByRole('link', { name: /detalles de la cuenta|account details/i })).toBeVisible();
  });

  test('Un usuario no autenticado es redirigido/bloqueado al intentar ver Mi cuenta', async ({ page }) => {
    await page.goto('/mi-cuenta/');
    await expect(page.locator('form.woocommerce-form-login, form.login')).toBeVisible();
  });
});
